<?php

namespace Pterodactyl\Http\Controllers\Admin\Servers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Server;

class ServerBackgroundController extends Controller
{
    /**
     * Upload a background image for a server and return the public path.
     */
    public function upload(Request $request, Server $server): JsonResponse
    {
        $this->authorize('update', $server);

        $request->validate([
            'background' => 'required|image|max:5120', // max 5MB
        ]);

        $path = $request->file('background')->store('prime/backgrounds', 'public');

        return response()->json(['path' => Storage::disk('public')->url($path)], 201);
    }
}
